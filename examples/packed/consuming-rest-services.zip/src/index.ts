import {
    ServerConfiguration, RouterConfiguration, ClientConfiguration,
    ConfiguredServer, BuiltInServers, BuiltInTransports, PluginConfiguration,
} from '@methodus/server';
import { DataController } from './controllers/local.controller';
import { RemoteService } from './controllers/remote.service';
@PluginConfiguration('@methodus/describe')
@ServerConfiguration(BuiltInServers.Express, { port: 6695 }) // instantiate express on given port
@RouterConfiguration(DataController, BuiltInServers.Express) // attach the DataController class to the Express instance 
@ClientConfiguration(RemoteService, BuiltInTransports.Http, 'https://jsonplaceholder.typicode.com')
export class Xserver extends ConfiguredServer {
    constructor() {
        super(Xserver);
    }
}

(() => {
    return new Xserver();
})();
