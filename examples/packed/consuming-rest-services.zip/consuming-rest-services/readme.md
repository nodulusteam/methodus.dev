## consuming-rest-services / methodus

### Install
npm install

### Start
npm start

