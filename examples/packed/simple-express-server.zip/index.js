"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Xserver_1;
"use strict";
const server_1 = require("@methodus/server");
const controller_1 = require("./controller");
let Xserver = Xserver_1 = class Xserver extends server_1.ConfiguredServer {
    constructor() {
        super(Xserver_1);
    }
};
Xserver = Xserver_1 = __decorate([
    server_1.ServerConfiguration(server_1.BuiltInServers.Express, { port: 6695 }) // instantiate express on given port
    ,
    server_1.RouterConfiguration(controller_1.DataController, server_1.BuiltInServers.Express.name) // attach the DataController class to the Express instance 
    ,
    __metadata("design:paramtypes", [])
], Xserver);
exports.Xserver = Xserver;
(() => {
    return new Xserver();
})();
