## simple-express-server / methodus

### Install
npm install

### Start
npm start

