"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const server_1 = require("@methodus/server");
const items = { 'item1': 'item 1 value', 'item2': 'item 2 value', 'item3': 'item 3 value', };
let DataController = class DataController {
    static async list() {
        return new server_1.MethodResult(items); // always return a MethodResult object
    }
    static async get(id) {
        return new server_1.MethodResult(items[id]);
    }
    static async error(item) {
        throw new server_1.MethodError('some error happend', 503);
    }
};
__decorate([
    server_1.Method("GET" /* Get */, '/'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], DataController, "list", null);
__decorate([
    server_1.Method("GET" /* Get */, '/:id'),
    __param(0, server_1.Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], DataController, "get", null);
__decorate([
    server_1.Method("GET" /* Get */, '/api/error/'),
    __param(0, server_1.Body('item')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], DataController, "error", null);
DataController = __decorate([
    server_1.MethodConfig('DataController') // anotate using the class Name - exact!
], DataController);
exports.DataController = DataController;
